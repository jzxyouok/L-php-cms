<?php

return array(
    'static_code' => array( //配置在表单中的键名 ,这个会是config[random]
        'title'   => '统计代码:', //表单的文字
        'type'    => 'textarea', //表单的类型：text、textarea、checkbox、radio、select等

        'value'   => '', //表单的默认值
    ),
);
