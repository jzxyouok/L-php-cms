<?php
/**
 * Created by PhpStorm.
 * User: Timothy Zhang
 * Date: 14-6-1
 * Time: 下午10:05
 */

namespace Oauth\Controller;


/**
 * 对外提供登陆服务
 * Class GreenController
 * @package Oauth\Controller
 */
class GreenController extends OauthBaseController
{

    //TODO provide Oauth2.0 login

} 