<?php
/**
 * Created by PhpStorm.
 * User: Timothy Zhang
 * Date: 14-6-1
 * Time: 下午10:03
 */

namespace Oauth\Controller;

use Common\Controller;

/**
 * Class OauthBaseController
 * @package Oauth\Controller
 */
class OauthBaseController extends Controller\BaseController
{


}