<?php

return array(

    // 数据库配置
    'DB_TYPE' => 'mysql',
    'DB_HOST' => SAE_MYSQL_HOST_M,
    'DB_NAME' => SAE_MYSQL_DB,
    'DB_USER' => SAE_MYSQL_USER,
    'DB_PWD' => SAE_MYSQL_PASS,
    'DB_PORT' => SAE_MYSQL_PORT,
    'DB_PREFIX' => 'green_',


    'SaeStorage' => 'upload',
    'FILE_UPLOAD_TYPE' => 'Sae'


);