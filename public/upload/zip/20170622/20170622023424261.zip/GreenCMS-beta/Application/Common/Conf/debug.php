<?php
return array(
    //'配置项'=>'配置值'
    'HTML_CACHE_ON' => false,
    'URL_CASE_INSENSITIVE' => true, //URL大小写不敏感

);