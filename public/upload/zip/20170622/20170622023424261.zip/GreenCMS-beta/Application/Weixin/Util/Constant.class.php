<?php
/**
 * Created by PhpStorm.
 * User: Timothy Zhang
 * Date: 14-10-23
 * Time: 下午10:33
 */

namespace Weixin\Util;


class Constant
{

} 