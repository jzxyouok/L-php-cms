<?php
namespace Think\Template\TagLib;

//use Think\Template\TagLib;
use Common\Util\GreenCMSTemplate;
/**
 * Class Green
 * @package Think\Template\TagLib
 */
class Green extends GreenCMSTemplate
{

    //move to  Common\Util\GreenCMSTemplate
}
	
	