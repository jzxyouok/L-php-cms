<?php
/**
 * Created by PhpStorm.
 * User: Timothy Zhang
 * Date: 14-7-25
 * Time: 下午11:21
 */
return array(//'配置项'=>'配置值'

);