<?php
/**
 * Created by PhpStorm.
 * User: TianShuo
 * Date: 2015/2/2
 * Time: 10:55
 */

namespace Common\Util;


class GreenMailContent
{

    public $to = "";
    public $subject = "";
    public $body = "";
    public $attachment = null;


}