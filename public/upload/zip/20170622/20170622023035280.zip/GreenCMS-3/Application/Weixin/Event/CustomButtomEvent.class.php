<?php
/**
 * Created by PhpStorm.
 * User: Timothy Zhang
 * Date: 14-8-16
 * Time: 上午7:54
 */

namespace Weixin\Event;


class CustomButtomEvent
{

} 