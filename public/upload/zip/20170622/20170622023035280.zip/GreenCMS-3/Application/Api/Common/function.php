<?php
/**
 * Created by GreenStudio GCS Dev Team.
 * File: function.php
 * User: Timothy Zhang
 * Date: 14-4-22
 * Time: 下午5:57
 */