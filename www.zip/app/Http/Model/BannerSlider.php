<?php

namespace App\Http\Model;

use Illuminate\Database\Eloquent\Model;

class BannerSlider extends Model
{
    protected $table='banner_sliders';
    protected $primarykey='id';
    public $timestamps=true;
}
